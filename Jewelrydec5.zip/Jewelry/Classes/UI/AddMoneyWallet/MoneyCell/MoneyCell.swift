//
//  MoneyCell.swift
//  Nisarga
//
//  Created by Hari Krish on 06/08/19.
//  Copyright © 2019 Developer. All rights reserved.
//

import UIKit

class MoneyCell: UICollectionViewCell {

    @IBOutlet weak var mBgView: UIView!
    @IBOutlet weak var mPriceLabel: CustomFontLabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
