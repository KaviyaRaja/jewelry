//
//  SimilarCollectionViewCell.swift
//  Jewelry
//
//  Created by Apple on 05/10/19.
//  Copyright © 2019 Developer. All rights reserved.
//

import UIKit

class SimilarCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
