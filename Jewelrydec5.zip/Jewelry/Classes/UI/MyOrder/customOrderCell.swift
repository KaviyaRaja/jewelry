//
//  customOrderCell.swift
//  Jewelry
//
//  Created by Febin Puthalath on 10/10/19.
//  Copyright © 2019 Developer. All rights reserved.
//

import UIKit

class customOrderCell: UICollectionViewCell {
    @IBOutlet weak var productImage: UIImageView!
    
    @IBOutlet weak var bgView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
