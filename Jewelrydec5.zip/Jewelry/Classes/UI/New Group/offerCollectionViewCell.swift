//
//  offerCollectionViewCell.swift
//  Jewelry
//
//  Created by Febin Puthalath on 04/10/19.
//  Copyright © 2019 Developer. All rights reserved.
//

import UIKit

class offerCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var productContainerView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var offerLabel: UILabel!
    @IBOutlet weak var offerImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
