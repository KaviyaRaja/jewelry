//
//  UploadCollectionViewCell.swift
//  Jewelry
//
//  Created by Febin Puthalath on 07/10/19.
//  Copyright © 2019 Developer. All rights reserved.
//

import UIKit

class UploadCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var selectedImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
