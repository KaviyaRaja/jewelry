//
//  SliderCollectionViewCell.swift
//  
//
//  Created by Apple on 25/06/19.
//

import UIKit

class SliderCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView : UIImageView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        
        
        // Initialization code
    }

}
