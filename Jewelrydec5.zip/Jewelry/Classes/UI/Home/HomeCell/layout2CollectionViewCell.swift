//
//  layout2CollectionViewCell.swift
//  Nisarga
//
//  Created by Hari Krish on 12/09/19.
//  Copyright © 2019 Developer. All rights reserved.
//

import UIKit

class layout2CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var mlayout2Label : UILabel!
    @IBOutlet weak var mlayout2View : UIView!
    @IBOutlet weak var mlayout2ImageView : UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
       
        // Initialization code
    }

}
