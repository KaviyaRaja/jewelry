//
//  layout1TableViewCell.swift
//  Nisarga
//
//  Created by Hari Krish on 12/09/19.
//  Copyright © 2019 Developer. All rights reserved.
//

import UIKit

class layout1TableViewCell: UITableViewCell
{
    @IBOutlet weak var mLayout1ImageView : UIImageView!
    @IBOutlet weak var mLayout1View : UIView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
